# 1
# my_set = {1, 2, 3, 4, 5}
# length = len(my_set)
# print(length)
# 2
# my_set = {1, 2, 3}
# my_set.add(4)
# print(my_set)
# 3
# set1 = {1, 2, 3}
# set2 = {3, 4, 5}
# result_set = set1.union(set2)
# print(result_set)
# 4
# my_set = {1, 2, 3, 4, 5}
# my_set.remove(3)
# print(my_set)
# 5
# set1 = {1, 2, 3}
# set2 = {3, 4, 5}
# result_set = set1.intersection(set2)
# print(result_set)
# 6
# set1 = {1, 2, 3}
# set2 = {2, 3, 4}
# set1.difference_update(set2)
# print(set1)
# 7
# set1 = {5, 7, 2, 1}
# set2 = {3, 8, 1}
# min_element = min(set1.union(set2))
# print(min_element)
# 8
# my_set = {1, 2, 3, 4, 5}
# element = int(input("O'chiriladigan elementni kiriting: "))
# my_set.discard(element)
# print(my_set)
# 9
# my_tuple = ()
# element = input("Tuple'ga qo'shiladigan elementni kiriting: ")
# my_tuple += (element,)
# print(my_tuple)
# 10
# ????
# 11
# my_tuple = (1, 2, 3, 4, 5)
# reversed_tuple = my_tuple[::-1]
# print(reversed_tuple)
# 12
# ???
# 13
# ??
# 14
# set1 = {1, 2, 3}
# set2 = {2, 3, 4}
# set1.intersection_update(set2)
# print(set1)
# 15
# my_set = {1, 2, 3, 4, 5}
# element = int(input("Tekshiriladigan elementni kiriting: "))
# if element in my_set:
#     print(f"{element} setda mavjud.")
# else:
#     print(f"{element} setda mavjud emas.")
# 16
